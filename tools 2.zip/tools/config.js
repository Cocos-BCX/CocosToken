module.exports = {
    // sale_contract_address:"0xe56E1CcA3cAC5E631669d69dc2fB0F430C384b42",
    // token_address:"0x7d8253214aC25050138Fcd0DdF1dF3EFDFf0c99D",
    // whitelist_file:"./tools/whitelist.txt",
    // from_account:"0x00a329c0648769A73afAc7F9381E08FB43dBEA72",
    // from_account_password:"",
    from_account:"0x00b9070E042fc812047B00aC41c0D3C631Ba06b1",
    from_account_pri_key:"0x14CC0B39EA3674B43A34B354D9C52FF04B280D3C4F7E05BD9EC29717673DA706",
    whitelist_flag:true,

    airdrop_contract_address:"0xe040911d3b35fb7fe0cdfa9d187c553d4a915d70",
    airdrop_address_file:"./tools/airdrop_address.txt",
    airdrop_value_file:"./tools/airdrop_value.txt",
    erc20_contract_address:"0x104b5bd75f5c509703858434408cb5a23b15cd7e",
    airdrop_from_account:"0x596c3Ff477F6069E4c9fFf48e0767661BE0fEE43"
};